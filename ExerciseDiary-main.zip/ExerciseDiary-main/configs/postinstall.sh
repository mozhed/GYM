#!/bin/sh

systemctl daemon-reload