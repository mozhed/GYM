#!/bin/sh

cp exercisediary /usr/bin/
cp ExerciseDiary.service /lib/systemd/system/
cp ExerciseDiary@.service /lib/systemd/system/